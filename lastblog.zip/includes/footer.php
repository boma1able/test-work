  
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="footer">
          <div class="copy">&copy; 2017 umm...design?</div>
          <div class="owner">Powered by boma</div>
        </div>
      </div>
    </div>
  </div>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  
</body>

</html>