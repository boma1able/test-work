<?php
  $config = array(
    'title' => 'umm...design?',
    'db' => array(
      'server'   => 'localhost',
      'username' => 'root',
      'password' => '',
      'name'     => 'last_db'
      ) 
  );

require "db.php";
?>