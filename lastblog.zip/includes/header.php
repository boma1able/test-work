


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <title>umm...design?</title>
  
  <link href="css/bootstrap.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
  <link href="https://fonts.googleapis.com/css?family=Dosis" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Gloria+Hallelujah" rel="stylesheet"> </head>

<body>

 <div class="container">
  <div class="row">
    <div class="col-md-12">
      <a href="index.php">
        <div class="logo"> <img class="img-responsive" src="img/logo.png" alt="logo-image"> </div>
      </a>
    </div>
  </div>
</div>
<nav class="navbar navbar-default">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#main-menu" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    </div>
    <div class="collapse navbar-collapse" id="main-menu">
    <ul class="nav navbar-nav">
        <li class="active" ><a href="index.php">home<span class="sr-only">(current)</span></a></li>
      </ul>
        <div class="login-panel"><a href="login.php">login</a></div>
    </div>
  </div>
</nav>












































